package vah13.com.bankapplicationformoney;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Secret extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secret);
    }
}
